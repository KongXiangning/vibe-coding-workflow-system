import subprocess,sys,json,os,datetime
from pathlib import Path
name=sys.argv[1];cmd=sys.argv[2:];e=Path('/tmp/vnext-maintenance-evidence');env=os.environ.copy();env['PATH']='/tmp/vnext-toolchain/node_modules/.bin:'+env['PATH'];env['npm_config_cache']='/tmp/vnext-npm-cache'
x=subprocess.run(cmd,cwd='/workspace/vibe-coding-workflow-system',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(e/(name+'.log')).write_text(x.stdout);(e/(name+'.run.json')).write_text(json.dumps({'command':cmd,'exit':x.returncode,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}));print(name,'exit',x.returncode);print(x.stdout[-1100:]);sys.exit(x.returncode)

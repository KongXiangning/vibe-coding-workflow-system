# Generic evidence transport only. Each business request is authored by the implementing AI.
from pathlib import Path
import json,subprocess,hashlib,datetime,shutil
E=Path('/tmp/vnext-maintenance-evidence'); R=E/'host'
def snapshot(dest):
 for base in ['docs','.workflow-system/PRODUCT.yaml','.workflow-system/records']:
  p=R/base
  if p.exists():
   q=dest/base;q.parent.mkdir(parents=True,exist_ok=True)
   if p.is_dir(): shutil.copytree(p,q,dirs_exist_ok=True)
   else: shutil.copy2(p,q)
def call(label,tool,action,request):
 d=E/'agent'/label;d.mkdir(parents=True,exist_ok=True); snapshot(d/'before')
 (d/'request.json').write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
 cmd=['node',str(R/'.workflow-system/runtime/support'/tool),action,'--root',str(R)]
 x=subprocess.run(cmd,input=json.dumps(request),text=True,capture_output=True)
 (d/'stdout.json').write_text(x.stdout);(d/'stderr.txt').write_text(x.stderr)
 (d/'run.json').write_text(json.dumps({'command':cmd,'exit':x.returncode,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
 snapshot(d/'after');return json.loads(x.stdout)
def read(label):return call(label,'product-maintenance.js','read',{'detail':'items'})
def apply(label,ops):
 for op in ops:
  p=R/op['path'];op['expected_sha256']=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 return call(label,'product-maintenance.js','apply',{'files':ops})
def doc(items):
 # JSON is a YAML subset; retain only author-supplied metadata/body.
 return '---\n'+json.dumps({'schema':'vnext-product-doc/v2','items':[i[0] for i in items]},ensure_ascii=False,indent=2)+'\n---\n\n'+'\n\n'.join(i[1] for i in items)+'\n'
def source(text):return {'kind':'text','text':text,'label':'隔离合成场景输入；不是实际业务用户事实'}

---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "REQ-IMPORT",
      "type": "requirement",
      "scope": "current",
      "sources": [
        {
          "kind": "file",
          "path": "docs/legacy/PRODUCT-NOTES.md",
          "sha256": "df25cf51d52c06528a52b06be0264140348cf38db82bab07b2823f80e7bf89a6"
        },
        {
          "kind": "file",
          "path": "docs/legacy/CR-ERROR.md",
          "sha256": "f5bc161d567b45f24cf7a32deb4e5912c0945ae89bd7c331e45f4132a2e3c493"
        }
      ],
      "task_bindings": [
        {
          "id": "B-HISTORY-A",
          "task": {
            "task_id": "legacy-import-a",
            "source": {
              "kind": "file",
              "path": "docs/legacy/TASK-A.md",
              "sha256": "268a73ef0e38c3ab9b5efdd4f14d0604a0240ec4481924de84d691f0a5196ae5"
            }
          },
          "role": "implementation",
          "coverage": "仅单设备 CSV 有效输入",
          "origin": "declared",
          "state": "active",
          "plan_items": [
            {
              "plan_id": "PLAN-IMPORT",
              "work_item_id": "A"
            }
          ]
        },
        {
          "id": "B-HISTORY-UNKNOWN",
          "task": {
            "task_id": null,
            "source": {
              "kind": "file",
              "path": "docs/legacy/TASK-A.md",
              "sha256": "268a73ef0e38c3ab9b5efdd4f14d0604a0240ec4481924de84d691f0a5196ae5",
              "lines": {
                "start": 4,
                "end": 4
              }
            }
          },
          "role": "reference",
          "coverage": "旧错误提示修复，实际覆盖待核对",
          "origin": "declared",
          "state": "active"
        }
      ],
      "assessment_id": "AS-A"
    },
    {
      "id": "REQ-AUDIT",
      "type": "requirement",
      "scope": "current",
      "sources": [
        {
          "kind": "file",
          "path": "docs/legacy/PRODUCT-NOTES.md",
          "sha256": "df25cf51d52c06528a52b06be0264140348cf38db82bab07b2823f80e7bf89a6"
        }
      ]
    }
  ]
}
---

## [REQ-IMPORT] 完整 CSV 导入
### 需求内容
单设备和双设备 CSV 导入。错误输入须解释具体错误，不丢弃已处理结果。
### 范围边界
保持离线，不含云同步；共享审计约束见 REQ-AUDIT。
### 验收要求
分别核对单设备、双设备和错误输入；只有单设备有效输入已有历史通过报告。

## [REQ-AUDIT] 共享审计
### 需求内容
导入结果可定位，日志不得包含原始个人数据。
### 范围边界
适用于所有导入阶段，无独立项目计划。
### 验收要求
按实际日志检查定位与脱敏；既有材料未说明是否交付。

### 人工补充
保留原始个人数据禁止项。

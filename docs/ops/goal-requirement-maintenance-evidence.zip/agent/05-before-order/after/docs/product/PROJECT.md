---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "PROJECT-IMPORT",
      "type": "project",
      "inventory": {
        "state": "reconciled",
        "checked_sources": [
          {
            "kind": "file",
            "path": "docs/legacy/PRODUCT-NOTES.md",
            "sha256": "df25cf51d52c06528a52b06be0264140348cf38db82bab07b2823f80e7bf89a6"
          },
          {
            "kind": "file",
            "path": "docs/legacy/PLAN.md",
            "sha256": "6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"
          },
          {
            "kind": "file",
            "path": "docs/legacy/TASK-A.md",
            "sha256": "268a73ef0e38c3ab9b5efdd4f14d0604a0240ec4481924de84d691f0a5196ae5"
          },
          {
            "kind": "file",
            "path": "docs/legacy/CR-ERROR.md",
            "sha256": "f5bc161d567b45f24cf7a32deb4e5912c0945ae89bd7c331e45f4132a2e3c493"
          }
        ],
        "unreviewed_sources": [],
        "note": "仅本次四份合成旧资料已核对；范围外未知。"
      }
    },
    {
      "id": "GOAL-IMPORT",
      "type": "goal",
      "scope": "current",
      "sources": [
        {
          "kind": "file",
          "path": "docs/legacy/PRODUCT-NOTES.md",
          "sha256": "df25cf51d52c06528a52b06be0264140348cf38db82bab07b2823f80e7bf89a6"
        }
      ]
    }
  ]
}
---

## [PROJECT-IMPORT] 导入业务
### 项目定位
可靠导入约定 CSV，保持离线；不要求云同步。
### 盘点范围与未核对项
已核对四份合成来源。旧 task 日期和代码版本未知，实际产品未运行，不代表全项目资料完整。

## [GOAL-IMPORT] 可靠导入
### 目标说明
约定文件可可靠导入；单设备报告不能证明总体目标达成。
### 范围边界
离线 CSV，不包括云同步。

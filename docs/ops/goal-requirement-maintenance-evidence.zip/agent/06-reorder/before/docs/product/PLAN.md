---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "PLAN-IMPORT",
      "type": "plan",
      "intent_state": "adopted",
      "targets": [
        {
          "target": "REQ-IMPORT",
          "coverage": "单设备、双设备和错误输入"
        }
      ],
      "work_items": [
        {
          "id": "A",
          "title": "单设备",
          "outcome": "单设备的实际行为与证据",
          "scope": "单设备；不扩建基础设施",
          "targets": [
            {
              "target": "REQ-IMPORT",
              "coverage": "单设备"
            }
          ],
          "state": "included",
          "origin": "initial",
          "sources": [
            {
              "kind": "file",
              "path": "docs/legacy/PLAN.md",
              "sha256": "6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"
            }
          ]
        },
        {
          "id": "B",
          "title": "双设备",
          "outcome": "双设备的实际行为与证据",
          "scope": "双设备；不扩建基础设施",
          "targets": [
            {
              "target": "REQ-IMPORT",
              "coverage": "双设备"
            }
          ],
          "state": "included",
          "origin": "initial",
          "sources": [
            {
              "kind": "file",
              "path": "docs/legacy/PLAN.md",
              "sha256": "6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"
            }
          ]
        },
        {
          "id": "C",
          "title": "错误解释",
          "outcome": "错误解释的实际行为与证据",
          "scope": "错误解释；不扩建基础设施",
          "targets": [
            {
              "target": "REQ-IMPORT",
              "coverage": "错误解释"
            }
          ],
          "state": "included",
          "origin": "initial",
          "sources": [
            {
              "kind": "file",
              "path": "docs/legacy/PLAN.md",
              "sha256": "6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"
            }
          ]
        }
      ],
      "sources": [
        {
          "kind": "file",
          "path": "docs/legacy/PLAN.md",
          "sha256": "6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"
        }
      ]
    }
  ]
}
---

## [PLAN-IMPORT] 沿用已采用安排
### 实施策略
旧计划已采用，保留 A/B/C 身份；不采用 Runtime task。
### 阶段与工作项说明
A 已有局部交付报告，B/C 尚待交付核对。数组原顺序 A、B、C。
### 调整与未决事项
旧采用日期未知；未发现数据库准备缺口，不自动扩建。

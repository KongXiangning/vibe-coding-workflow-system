---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "CHG-ERROR",
      "type": "change",
      "recorded_at": "2026-10-09T16:53:27.256521+00:00",
      "basis": {
        "kind": "document-edit",
        "text": "整理已采用旧 CR；非本轮新业务决定",
        "sources": [
          {
            "kind": "file",
            "path": "docs/legacy/CR-ERROR.md",
            "sha256": "f5bc161d567b45f24cf7a32deb4e5912c0945ae89bd7c331e45f4132a2e3c493"
          }
        ]
      },
      "deltas": [
        {
          "target": "REQ-IMPORT",
          "before": "只接受有效输入",
          "after": "错误输入须解释具体错误，不丢弃已处理结果",
          "note": "历史发生日期未知"
        }
      ]
    }
  ]
}
---

## [CHG-ERROR] 重要旧变化
### 变更说明
保留旧 CR 的明确前后意图；本记录时间为本次整理时间。
### 影响与未同步项
需求已包含错误输入规则，代码交付未证实。

---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "CHG-ERROR",
      "type": "change",
      "recorded_at": "2026-10-09T16:53:27.256521+00:00",
      "basis": {
        "kind": "document-edit",
        "text": "整理已采用旧 CR；非本轮新业务决定",
        "sources": [
          {
            "kind": "file",
            "path": "docs/legacy/CR-ERROR.md",
            "sha256": "f5bc161d567b45f24cf7a32deb4e5912c0945ae89bd7c331e45f4132a2e3c493"
          }
        ]
      },
      "deltas": [
        {
          "target": "REQ-IMPORT",
          "before": "只接受有效输入",
          "after": "错误输入须解释具体错误，不丢弃已处理结果",
          "note": "历史发生日期未知"
        }
      ]
    }
  , {"id":"CHG-ORDER","type":"change","recorded_at":"2026-10-09T16:53:51.005370+00:00","basis":{"kind":"delegated","text":"合成当前明确安排决定","sources":[{"kind":"text","text":"当前决定：接下来 B、C，把 B 移到已交付 A 前展示，保留历史；不执行任务，不归档整段聊天。","label":"隔离合成场景输入；不是实际业务用户事实"}]},"deltas":[{"target":"PLAN-IMPORT","before":"A、B、C","after":"B、A、C","note":"稳定工作项 B/A/C；A 交付历史不变"}]}]
}
---

## [CHG-ERROR] 重要旧变化
### 变更说明
保留旧 CR 的明确前后意图；本记录时间为本次整理时间。
### 影响与未同步项
需求已包含错误输入规则，代码交付未证实。

## [CHG-ORDER] 当前展示安排
### 变更说明
B 移至 A 前，接下来业务项为 B、C。
### 影响与未同步项
仅展示安排，不影响历史任务或交付日期，不执行任务。

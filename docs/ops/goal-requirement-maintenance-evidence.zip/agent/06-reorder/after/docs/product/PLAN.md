---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {"id":"PLAN-IMPORT","type":"plan","intent_state":"adopted","targets":[{"target":"REQ-IMPORT","coverage":"单设备、双设备和错误输入"}],"work_items":[{"id":"B","title":"双设备","outcome":"双设备的实际行为与证据","scope":"双设备；不扩建基础设施","targets":[{"target":"REQ-IMPORT","coverage":"双设备"}],"state":"included","origin":"initial","sources":[{"kind":"file","path":"docs/legacy/PLAN.md","sha256":"6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"}]},{"id":"A","title":"单设备","outcome":"单设备的实际行为与证据","scope":"单设备；不扩建基础设施","targets":[{"target":"REQ-IMPORT","coverage":"单设备"}],"state":"included","origin":"initial","sources":[{"kind":"file","path":"docs/legacy/PLAN.md","sha256":"6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"}]},{"id":"C","title":"错误解释","outcome":"错误解释的实际行为与证据","scope":"错误解释；不扩建基础设施","targets":[{"target":"REQ-IMPORT","coverage":"错误解释"}],"state":"included","origin":"initial","sources":[{"kind":"file","path":"docs/legacy/PLAN.md","sha256":"6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"}]}],"sources":[{"kind":"file","path":"docs/legacy/PLAN.md","sha256":"6e741bb019c64a4ecd50b08b57c93dba6f935503a40f663cd6b8fdcbd499b1d7"}]}
  ]
}
---

## [PLAN-IMPORT] 当前局部导入安排
### 实施策略
沿用原范围，明确接下来 B、C；不要求全项目总体计划。
### 阶段与工作项说明
当前展示 B、A、C；A 保留单设备有效输入交付报告，B/C 待实现核对。
### 调整与未决事项
原数组 A、B、C 见 CHG-ORDER；真实任务状态、日期、原报告不变。

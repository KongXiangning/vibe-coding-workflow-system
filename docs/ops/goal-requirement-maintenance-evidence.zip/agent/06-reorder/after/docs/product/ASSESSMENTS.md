---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "AS-A",
      "type": "assessment",
      "target": "REQ-IMPORT",
      "target_basis": {
        "kind": "file",
        "path": "docs/legacy/PRODUCT-NOTES.md",
        "sha256": "df25cf51d52c06528a52b06be0264140348cf38db82bab07b2823f80e7bf89a6"
      },
      "target_definition_sha256": null,
      "checked_at": "2026-10-09T16:53:27.256508+00:00",
      "subject": {
        "kind": "unknown",
        "value": null
      },
      "implementation": "partial-reported",
      "verification": "pass-reported",
      "sources": [
        {
          "kind": "file",
          "path": "docs/legacy/TASK-A.md",
          "sha256": "268a73ef0e38c3ab9b5efdd4f14d0604a0240ec4481924de84d691f0a5196ae5"
        }
      ]
    }
  ]
}
---

## [AS-A] 原单设备报告
### 覆盖范围
单设备 CSV 有效输入，不覆盖双设备和错误输入。
### 交付与验证依据
旧 TASK-A 报告称该范围已交付并通过，代码版本和日期未知；实施 AI 本轮未复现业务。
### 剩余与待核对
双设备、错误输入和共享审计尚待核对；旧 PASS 不提升为当前全量通过。

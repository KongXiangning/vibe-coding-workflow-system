import {op,pApply,pRead,body,doc,src,capture,save,evidence} from './driver.mjs';
op('00-task-before','assistance','task-status',{});
pRead('00-product-before');
const manifest={schema:'vnext-product-manifest/v2',project_id:'synthetic-local-invoice-evolution',entry:'docs/product/PROJECT.md',managed_paths:['docs/product/*.md'],source_paths:['docs/product/history/**','docs/evidence/**','synthetic/**','docs/workflow/**'],capture_paths:['docs/product/history/**'],exclude_paths:[],maintenance:'enabled'};
pApply('00-manifest',[{path:'.workflow-system/PRODUCT.yaml',content:JSON.stringify(manifest,null,2)+'\n'}]);
const original='我们的本地发票工具首发给小微企业单人使用，目标是把月底核对时间缩短一半。必须始终离线，不上传发票原件或客户字段。当前完整要求包括：导入单张 CSV 中的整数金额行并指出行号；汇总可导出 CSV；以后可能支持多个账套。采用的设计是在本地解析、整数分计算并保留失败行，汇总导出尚未实现，多账套只做远期方向。';
capture('00-baseline',original);
save(`${evidence}/00-host-decisions.md`,'本次为隔离的合成验收项目。宿主 Agent 阅读原始业务材料后决定：单人小微企业为首发受众；耗时减半为一个尚未测量的目标；离线和不上传是全程独立约束；导入有效整数金额与失败行号为同一完整承诺；CSV 汇总导出仍为当前未实施需求；多账套仅候选远期范围。设计采用本地解析与整数分，采用不等于完成。为已有导入初次交付、导入后续完整性核对、导出和远期多账套安排稳定工作项。只创建初次整数导入真实服务任务，其余安排不创建任务。\n');

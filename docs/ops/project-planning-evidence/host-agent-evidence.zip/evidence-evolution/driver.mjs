import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
export const root='/workspace/shared/project-planning-20261008/host-evolution';
export const evidence='/workspace/shared/project-planning-20261008/evidence-evolution';
export const hash=x=>createHash('sha256').update(x).digest('hex');
export const file=p=>fs.readFileSync(path.join(root,p),'utf8');
export const digest=p=>fs.existsSync(path.join(root,p))?hash(fs.readFileSync(path.join(root,p))):null;
export const save=(p,text)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,text)};
export function op(label,kind,command,input){
 save(`${evidence}/${label}.input.json`,JSON.stringify(input,null,2)+'\n');
 const program=kind==='product'?'.workflow-system/runtime/support/product-maintenance.js':'.workflow-system/runtime/support/assistance.mjs';
 const result=spawnSync('node',[program,command,'--root',root],{cwd:root,input:JSON.stringify(input),encoding:'utf8',maxBuffer:24*1024*1024});
 save(`${evidence}/${label}.output.json`,result.stdout);save(`${evidence}/${label}.stderr.txt`,result.stderr);
 let data;try{data=JSON.parse(result.stdout)}catch{}
 save(`${evidence}/${label}.receipt.json`,JSON.stringify({label,kind,command,exit:result.status,recorded_at:new Date().toISOString(),input_sha256:hash(JSON.stringify(input)),output_sha256:hash(result.stdout)},null,2)+'\n');
 console.log(JSON.stringify({label,exit:result.status,status:data?.status,ref:data?.ref,task_id:data?.task_id,files:data?.files?.map(x=>({path:x.path,status:x.status,diagnostics:x.diagnostics})),diagnostics:data?.diagnostics}));
 return data;
}
export const pRead=(label,ids,extra={})=>op(label,'product','read',{detail:'items',...(ids?{item_ids:ids}:{}),...extra});
export const pApply=(label,files)=>op(label,'product','apply',{expected_manifest_sha256:digest('.workflow-system/PRODUCT.yaml'),files:files.map(f=>({expected_sha256:digest(f.path),...f}))});
export const body=(id,title,sections)=>`## [${id}] ${title}\n\n`+Object.entries(sections).map(([h,t])=>`### ${h}\n${t}\n`).join('\n');
export const doc=items=>'---\n'+JSON.stringify({schema:'vnext-product-doc/v2',items:items.map(x=>x.metadata)},null,2)+'\n---\n\n'+items.map(x=>x.body).join('\n');
export const src=(path,extra={})=>({kind:'file',path,sha256:digest(path),...extra});
export const link=(id,relation,target,source,reason)=>({id,relation,target,origin:'declared',state:'active',sources:[source],...(reason?{reason}:{})});
export const capture=(label,text)=>op(`${label}-capture`,'product','capture',{path:`docs/product/history/${label}-input.txt`,text});
export const parseOutput=label=>JSON.parse(fs.readFileSync(`${evidence}/${label}.output.json`,'utf8'));
export function stageBegin(n,text,ids,impact=[]){
 const localSkill=file('.agents/skills/maintain-project/SKILL.md');
 save(`${evidence}/${n}-skill-reload.json`,JSON.stringify({path:'.agents/skills/maintain-project/SKILL.md',sha256:hash(localSkill),read_at:new Date().toISOString()},null,2)+'\n');
 op(`${n}-task-before`,'assistance','task-status',{});
 const before=pRead(`${n}-before`,ids,impact.length?{impact_ids:impact}:{});
 capture(n,text);
 return {before,s:src(`docs/product/history/${n}-input.txt`),item:id=>before.usable_items.find(x=>x.id===id),text};
}
export function change(id,s,text,deltas,description,unsynced){return {metadata:{id,type:'change',recorded_at:new Date().toISOString(),basis:{kind:'user',text,sources:[s]},deltas,sources:[s]},body:body(id,'本次授权业务变更',{'变更说明':description,'影响与未同步项':unsynced})}}
export function changeFile(c){return digest('docs/product/CHANGES.md')?{path:'docs/product/CHANGES.md',append:[c]}:{path:'docs/product/CHANGES.md',content:doc([c])}}
export const decision=(n,text)=>save(`${evidence}/${n}-host-decision.md`,text+'\n');

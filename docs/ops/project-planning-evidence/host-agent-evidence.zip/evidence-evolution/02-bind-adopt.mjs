import {op,pApply,pRead,src,parseOutput,save,root} from './driver.mjs';
const prep=parseOutput('01-task-prepare');
save(`${root}/docs/evidence/task-prepared.json`,JSON.stringify(prep,null,2)+'\n');
const task={task_id:prep.task_id,plan_ref:prep.ref,step_id:'S-IMPORT',source:src('docs/evidence/task-prepared.json'),label:'实际 assistance 创建的合成导入任务'};
const binding={id:'B-IMPORT-FIRST',task,role:'implementation',coverage:'单列 amount CSV 初始整数解析、保留失败原值和物理行号；非全部 CSV 兼容、非导出或产品耗时验证',origin:'declared',state:'active',sources:[src('docs/product/history/00-baseline-input.txt')],plan_items:[{plan_id:'PLAN-LAUNCH',work_item_id:'WI-IMPORT-FIRST'}]};
pApply('02-bind-before-code',[{path:'docs/product/REQUIREMENTS.md',preimage_path:'docs/product/history/02-before-binding.md',updates:[{id:'REQ-IMPORT',metadata:{task_bindings:[binding]}}]}]);
pRead('02-binding-readback',['REQ-IMPORT','PLAN-LAUNCH']);
op('02-task-adopt','assistance','task',{action:'adopt',task_id:prep.task_id,plan_ref:prep.ref,focus:true,decision_source:'Synthetic acceptance task delegated by parent',decision_text:'Create a real task and binding for integer CSV import, create a small local parser and actually run a Node test that passes for its initial documented integer scope.',idempotency_key:'adopt-synthetic-integer-import-first'});
op('02-task-status','assistance','task-status',{detail:'task',task_ref:prep.task_id});

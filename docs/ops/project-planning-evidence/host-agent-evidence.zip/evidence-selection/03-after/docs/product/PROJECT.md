---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "PROJ-MERCHANT",
      "type": "project",
      "inventory": {
        "state": "partial",
        "checked_sources": [
          {
            "kind": "file",
            "path": "docs/source/merchant-brief.md",
            "sha256": "bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/checkout-design.md",
            "sha256": "830c2b3a9b81eb9a56d164e20ca22033e6d2a779c2b68daed3949f9f3fd79620",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/operations-older.md",
            "sha256": "bcd2aa18aedaa0d9fe8069fc8c0cf2ce5c628e3d69b9110371fe205c6e9fdf43",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/support-draft.md",
            "sha256": "a259b47828a2cdb865d21241e550ed41858c5b581883c111bb337ce149e9080c",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/decisions.md",
            "sha256": "01eee8501dbf7980727b94f4344f07cab25a2275b3f113dd05465f7df13ab443",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          }
        ],
        "unreviewed_sources": [
          {
            "kind": "file",
            "path": "docs/source/provider-production.md",
            "note": "Known path; not obtained; production capabilities unknown"
          }
        ]
      }
    }
  ]
}
---

## [PROJ-MERCHANT] 商户原支付与退款支持
### 项目定位
客服定位原支付及退款记录，查询失败可重查；后续退款执行，审计与异步队列是可选方向。支付留在提供方，拒绝内部钱包。
### 盘点范围与未核对项
inventory 保留已读来源和未取得的 docs/source/provider-production.md。实际交付仅见限域 assessments；不能从来源读取完整推出产品完成。
### 安排与历史位置
当前已知范围安排、下一项选择和未决结论由 PLAN-SUPPORT 维护。此前无计划的选择见 docs/product/history/project-before-stage3.md；TASK-001 的原始计划和历史保持原身份，不表示完整交付。
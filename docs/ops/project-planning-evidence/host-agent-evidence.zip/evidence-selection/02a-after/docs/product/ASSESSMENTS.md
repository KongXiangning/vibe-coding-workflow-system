---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "ASM-LOOKUP-INITIAL",
      "type": "assessment",
      "target": "REQ-LOOKUP",
      "target_basis": {
        "kind": "file",
        "path": "docs/product/history/requirements-stage1.md",
        "sha256": "bb6a9224e44207ef0e32a61554b7d8f4d096e540dd46382eec6c107f1316756d",
        "item_id": "REQ-LOOKUP"
      },
      "target_definition_sha256": "dd94a4edc592f5781032eb7ceb0ef846f6b5d6a8b7fa1031e7c63a63254c81d1",
      "checked_at": "2026-10-08T03:36:30.390Z",
      "subject": {
        "kind": "working-copy",
        "value": "sha256:a1f487cca44246867ed407b4d301ff8b487a237354202e2f57d28d60af5940cf (exact two-file manifest in report)"
      },
      "implementation": "partial-reported",
      "verification": "pass-reported",
      "sources": [
        {
          "kind": "file",
          "path": "docs/evidence/lookup-success.json",
          "sha256": "72f10bdcb61849417f35aa836fc8c6c63223120e6e40c8c5c419dedc32197227"
        }
      ],
      "pending_sources": []
    }
  ]
}
---

## [ASM-LOOKUP-INITIAL] 初始原支付查询部分交付
### 覆盖范围
仅一个合成已知 provider ID 的成功查询适配器；返回对应支付 ID 与整数分金额。不是生产提供方验证，不包含退款记录、缺失或错误输入。
### 交付与验证依据
Agent 实际运行 node --test test/lookup-success.test.mjs；报告含完整命令、输出、退出码、时间与两文件 SHA-256。实现与自检不是独立评审。pass-reported 仅限此检查范围。
### 剩余与待核对
是否已退款、支付缺失、查询错误、重查提示、生产能力均未验证。退款执行不在任务范围。未有正式评审、步骤完成或 Git 提交；这些事实不因任务后续关闭消失。

// Isolated acceptance adapter: only successful lookup behavior is established.
export async function lookupOriginalPayment(order, provider) {
  const payment = await provider.lookupPayment(order.payment_id);
  return { payment_id: payment.id, amount_cents: payment.amount_cents };
}

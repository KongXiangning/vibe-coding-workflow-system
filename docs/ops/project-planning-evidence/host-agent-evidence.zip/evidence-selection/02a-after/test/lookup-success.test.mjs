import test from 'node:test';
import assert from 'node:assert/strict';
import {lookupOriginalPayment} from '../src/lookup.mjs';
test('successful original payment lookup uses provider ID and integer cents', async () => {
 const requested=[];
 const payments = new Map([['pay_fixture_17',{id:'pay_fixture_17',amount_cents:1299}]]);
 const provider={lookupPayment:async id=>{requested.push(id);return payments.get(id);}};
 const result=await lookupOriginalPayment({payment_id:'pay_fixture_17'},provider);
 assert.deepEqual(requested,['pay_fixture_17']);
 assert.deepEqual(result,{payment_id:'pay_fixture_17',amount_cents:1299});
});

---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "CHG-LOOKUP-EXPANSION",
      "type": "change",
      "recorded_at": "2026-10-08T03:46:31.103Z",
      "basis": {
        "kind": "user",
        "text": "这轮查询先到这里，未覆盖的情况保留；关闭这个任务。现在要求还要查到已退款记录，并增加查询失败后的重查提示。按实际结果更新需求，再选择下一项；先保存建议，不启动。",
        "sources": [
          {
            "kind": "file",
            "path": "docs/evidence/stage2-request.txt",
            "sha256": "dc4a4486c5018e56ca35c5eb194fb631eaf71dd35b09b1f57ccfffac97f723c4"
          }
        ]
      },
      "deltas": [
        {
          "target": "REQ-LOOKUP",
          "before": "查询原支付并回答是否退款；异常具体交互未明确",
          "after": "明确已退款记录可检索，并增加失败后的重查提示",
          "note": "保留原支付查询及设计约束；不是已交付声明"
        }
      ]
    }
  ]
}
---

## [CHG-LOOKUP-EXPANSION] 查询覆盖扩展
### 变更说明
依据本轮明确请求保留查询并明确已退款记录查询，增加失败重查提示。旧正文已按真实字节留存 history。
### 影响与未同步项
TASK-001 历史不改，不重开。新范围尚未实现/验证；下一项只保存建议。

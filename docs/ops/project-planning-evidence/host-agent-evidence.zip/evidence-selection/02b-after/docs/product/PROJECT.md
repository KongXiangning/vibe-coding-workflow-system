---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "PROJ-MERCHANT",
      "type": "project",
      "inventory": {
        "state": "partial",
        "checked_sources": [
          {
            "kind": "file",
            "path": "docs/source/merchant-brief.md",
            "sha256": "bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/checkout-design.md",
            "sha256": "830c2b3a9b81eb9a56d164e20ca22033e6d2a779c2b68daed3949f9f3fd79620",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/operations-older.md",
            "sha256": "bcd2aa18aedaa0d9fe8069fc8c0cf2ce5c628e3d69b9110371fe205c6e9fdf43",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/support-draft.md",
            "sha256": "a259b47828a2cdb865d21241e550ed41858c5b581883c111bb337ce149e9080c",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/decisions.md",
            "sha256": "01eee8501dbf7980727b94f4344f07cab25a2275b3f113dd05465f7df13ab443",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          }
        ],
        "unreviewed_sources": [
          {
            "kind": "file",
            "path": "docs/source/provider-production.md",
            "note": "Known path; not obtained; production capabilities unknown"
          }
        ]
      }
    }
  ]
}
---

## [PROJ-MERCHANT] 商户原支付与退款支持
### 项目定位
客服定位原卡支付及已退款记录，失败后可重查；退款执行仍为后续方向。支付留在提供方，不建内部钱包。
### 盘点范围与未核对项
已读五份合成资料及实际隔离查询报告，库存仍 partial；生产能力 note 已知但未取得。
### 当前选择与理由
TASK-001 按用户指令关闭，仅成功 provider-ID 查询在合成环境得到验证，未覆盖内容不消失。建议下一项是已退款记录查询，优先补足是否已退款的核心客服问题；之后处理失败重查提示与缺失支付契约。这里只保存建议，未准备或启动新任务，无总体计划。
### 未决事项与前提
生产 note 未读影响真实集成/交付；已退款记录形态需确认。30/45 天退款窗口冲突、执行重试/幂等规则未定，影响退款执行而不阻断隔离只读查询。整数分和禁止卡/客户日志已有 DES-PROVIDER，不新增重复文件。审计导出/异步队列可选无上线承诺。
### 保留的决定
钱包拒绝决定及理由不变。TASK-001 原身份、计划、执行与测试历史保留；关闭未完成步骤不表示验收通过。
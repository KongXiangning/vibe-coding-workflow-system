import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
export const root='/workspace/shared/project-planning-20261008/host-selection';
export const ev='/workspace/shared/project-planning-20261008/evidence-selection';
export const hash=p=>fs.existsSync(path.join(root,p))?createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex'):null;
export const src=(p,note)=>({kind:'file',path:p,...(hash(p)?{sha256:hash(p)}:{}),...(note?{note}:{})});
export const doc=items=>'---\n'+JSON.stringify({schema:'vnext-product-doc/v2',items:items.map(x=>x.metadata)},null,2)+'\n---\n\n'+items.map(x=>x.body).join('\n\n')+'\n';
export function save(name,value){fs.mkdirSync(ev,{recursive:true});fs.writeFileSync(path.join(ev,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n');}
export function call(name,api,command,request={},cwd=root){save(name+'.request.json',request);const exe=api==='product'?path.join(root,'.workflow-system/runtime/support/product-maintenance.js'):path.join(root,'.workflow-system/runtime/support/assistance.mjs');const args=[exe,command,'--root',cwd];const start=new Date().toISOString();const r=spawnSync(process.execPath,args,{cwd,input:JSON.stringify(request),encoding:'utf8',maxBuffer:20*1024*1024});save(name+'.stdout.json',r.stdout);save(name+'.stderr.txt',r.stderr);save(name+'.invocation.json',{started_at:start,ended_at:new Date().toISOString(),command:[process.execPath,...args],exit_status:r.status});let out;try{out=JSON.parse(r.stdout)}catch{throw Error(r.stdout+r.stderr)}return out;}
export function snap(name){const dir=path.join(ev,name);fs.mkdirSync(dir,{recursive:true});for(const p of ['.workflow-system/PRODUCT.yaml','docs/product','docs/source','.workflow-system/records','docs/workflow/CURRENT_TASK.md','src','test','docs/evidence'])if(fs.existsSync(path.join(root,p)))fs.cpSync(path.join(root,p),path.join(dir,p),{recursive:true});save(name+'.timestamp.txt',new Date().toISOString());}
export function writeNew(name,files){return call(name,'product','apply',{expected_manifest_sha256:hash('.workflow-system/PRODUCT.yaml'),files:files.map(([p,items])=>({path:p,expected_sha256:hash(p),content:doc(items)}))});}
export function patch(name,files){return call(name,'product','apply',{expected_manifest_sha256:hash('.workflow-system/PRODUCT.yaml'),files:files.map(([p,ops])=>({path:p,expected_sha256:hash(p),...ops}))});}

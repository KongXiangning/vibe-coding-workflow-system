# Supplied synthetic explicit prior decision
Do not build an internal wallet for this product. Payments remain with the provider.

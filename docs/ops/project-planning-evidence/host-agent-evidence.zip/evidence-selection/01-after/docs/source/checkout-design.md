# Supplied synthetic checkout design (not an Agent verification report)
Existing checkout stores provider payment_id on each order. Amounts use integer cents. Logs must not include card/customer payloads. Provider read-only payment lookup is already available. Production capability note is known at docs/source/provider-production.md; its contents have not been obtained.

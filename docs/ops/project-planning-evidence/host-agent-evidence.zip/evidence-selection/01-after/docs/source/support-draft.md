# Supplied synthetic current draft support manual
Staff can refund within 45 days. No authoritative resolution against the older operations notes has been supplied. Refund execution retry/idempotency rules have not been decided.

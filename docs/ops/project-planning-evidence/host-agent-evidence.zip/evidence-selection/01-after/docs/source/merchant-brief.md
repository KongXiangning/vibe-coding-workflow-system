# Supplied synthetic merchant brief (not an implementation observation)
A small merchant wants support staff to find the original card payment and answer whether a refund has already happened. The implementation team wants refund execution later. Audit export and asynchronous refund queues are optional future ideas without a launch commitment.

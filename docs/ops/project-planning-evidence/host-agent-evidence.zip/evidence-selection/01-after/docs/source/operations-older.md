# Supplied synthetic older operations notes
Staff can refund within 30 days.

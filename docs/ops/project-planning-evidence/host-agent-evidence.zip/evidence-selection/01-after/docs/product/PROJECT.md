---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "PROJ-MERCHANT",
      "type": "project",
      "inventory": {
        "state": "partial",
        "checked_sources": [
          {
            "kind": "file",
            "path": "docs/source/merchant-brief.md",
            "sha256": "bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/checkout-design.md",
            "sha256": "830c2b3a9b81eb9a56d164e20ca22033e6d2a779c2b68daed3949f9f3fd79620",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/operations-older.md",
            "sha256": "bcd2aa18aedaa0d9fe8069fc8c0cf2ce5c628e3d69b9110371fe205c6e9fdf43",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/support-draft.md",
            "sha256": "a259b47828a2cdb865d21241e550ed41858c5b581883c111bb337ce149e9080c",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          },
          {
            "kind": "file",
            "path": "docs/source/decisions.md",
            "sha256": "01eee8501dbf7980727b94f4344f07cab25a2275b3f113dd05465f7df13ab443",
            "note": "Supplied synthetic fixture; read by host, not implementation verification"
          }
        ],
        "unreviewed_sources": [
          {
            "kind": "file",
            "path": "docs/source/provider-production.md",
            "note": "Known path; not obtained; production capabilities unknown"
          }
        ]
      }
    }
  ]
}
---

## [PROJ-MERCHANT] 商户原支付与退款支持
### 项目定位
支持人员定位订单的原卡支付，回答是否已经退款；后续考虑退款执行。支付留在支付提供方，内部钱包此前明确拒绝。
### 盘点范围与未核对项
已读五份合成资料，只有来源内范围已盘点；不是生产验证。docs/source/provider-production.md 已知但未取得，不编造其内容。
### 当前选择与理由
不建总体计划。本轮只准备原支付查询：已有订单 payment_id 和只读 provider lookup，能最小化权限与风险并直接服务客服；没有启动实现。下一步建议检查已准备任务范围。
### 未决事项与前提
生产能力资料未读，影响真实集成与交付确认，隔离准备可继续。退款窗口 30 天（旧运营）与 45 天（当前草稿）冲突，需权威业务决定，读查询不依赖该决定。退款执行重试/幂等规则未决定，执行设计前须明确。退款记录形态、找不到支付与查询错误行为尚未验证。金额整数分、禁止卡/客户 payload 日志已在设计中明确，无需新建同义规则文件。审计导出及异步队列仅未来可选建议。
### 保留的决定
内部钱包仍为已拒绝方案，理由是支付留在提供方；没有新的反转依据。

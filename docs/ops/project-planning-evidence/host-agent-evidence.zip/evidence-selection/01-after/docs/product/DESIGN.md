---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {
      "id": "DES-PROVIDER",
      "type": "design",
      "intent_state": "adopted",
      "sources": [
        {
          "kind": "file",
          "path": "docs/source/checkout-design.md",
          "sha256": "830c2b3a9b81eb9a56d164e20ca22033e6d2a779c2b68daed3949f9f3fd79620"
        },
        {
          "kind": "file",
          "path": "docs/source/decisions.md",
          "sha256": "01eee8501dbf7980727b94f4344f07cab25a2275b3f113dd05465f7df13ab443"
        }
      ]
    }
  ]
}
---

## [DES-PROVIDER] 复用提供方支付标识和查询
### 设计方案
订单已有 provider payment_id，原支付查询复用提供方只读 lookup。支付资金留在提供方，明确不建立内部钱包。
### 约束与取舍
金额使用整数分；日志禁止卡和客户 payload。生产能力说明未取得。退款窗口 30/45 天冲突及退款执行重试/幂等未决，不阻塞隔离只读查询准备。
### 实际实现与差异
以上现状来自合成设计资料，不是 Agent 验证。尚未运行查询检查或实现。

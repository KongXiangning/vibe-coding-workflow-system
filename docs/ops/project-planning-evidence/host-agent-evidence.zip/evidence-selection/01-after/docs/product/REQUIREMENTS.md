---
{
  "schema": "vnext-product-doc/v2",
  "items": [
    {"id":"REQ-LOOKUP","type":"requirement","scope":"current","sources":[{"kind":"file","path":"docs/source/merchant-brief.md","sha256":"bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264"}],"task_bindings":[{"id":"BIND-LOOKUP-INITIAL","task":{"task_id":"task-a032ed964e2eeb5cedbebc0abf83caf9","source":{"kind":"file","path":".workflow-system/records/events/key-99830e2924afe07e417d210e9238a7df69f66724ca87bf60e03f53e660f0da20.json","sha256":"f8883e32de81128f5cb50ed6de6233f689481183c8c4d21fe6c61ebd22fed0a3"},"label":"TASK-001","plan_ref":".workflow-system/records/events/key-99830e2924afe07e417d210e9238a7df69f66724ca87bf60e03f53e660f0da20.json"},"role":"implementation","coverage":"原支付 provider ID 成功查询的最小路径；退款、缺失及错误输入尚未实现/验证","origin":"declared","state":"active","sources":[{"kind":"text","label":"Stage 1 request","text":"现在不建总体计划，只准备原支付查询这一个任务"}]}]},
    {
      "id": "REQ-REFUND",
      "type": "requirement",
      "scope": "planned",
      "sources": [
        {
          "kind": "file",
          "path": "docs/source/merchant-brief.md",
          "sha256": "bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264"
        }
      ]
    },
    {
      "id": "REQ-AUDIT",
      "type": "requirement",
      "scope": "candidate",
      "sources": [
        {
          "kind": "file",
          "path": "docs/source/merchant-brief.md",
          "sha256": "bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264"
        }
      ]
    },
    {
      "id": "REQ-QUEUE",
      "type": "requirement",
      "scope": "candidate",
      "sources": [
        {
          "kind": "file",
          "path": "docs/source/merchant-brief.md",
          "sha256": "bb50181842f958a8b1ea19684d441d01c7fb11ec8085c23131fb98224965d264"
        }
      ]
    }
  ]
}
---

## [REQ-LOOKUP] 原卡支付和退款状态查询
### 需求内容
客服利用订单中已保存的 provider payment_id 找到原卡支付，并回答是否已经退款。
### 范围边界
只读查询；不执行退款、不管理资金、不建钱包。金额和日志遵循 DES-PROVIDER。
### 验收要求
可以按 provider payment_id 显示对应支付；退款状态须与提供方记录相符。缺失、已退款及错误输入的可用数据形态与具体交互仍未确认，不能视为已交付。

## [REQ-REFUND] 后续退款执行
### 需求内容
团队希望后续允许支持人员执行退款。
### 范围边界
本轮不实现；30/45 天窗口冲突、执行重试/幂等规则与生产能力尚待明确。
### 验收要求
执行依据权威退款窗口，重试不产生重复退款；详细规则未决定，不自行填充。

## [REQ-AUDIT] 可选审计导出
### 需求内容
未来可考虑审计导出。
### 范围边界
没有上线承诺；不是查询或退款本轮的强制前提。
### 验收要求
未记录，采用前再明确内容和用途。

## [REQ-QUEUE] 可选异步退款队列
### 需求内容
未来可考虑异步退款队列。
### 范围边界
没有上线承诺；不假设同步退款必须先建队列。
### 验收要求
未记录，须先有实际吞吐/可靠性需求。

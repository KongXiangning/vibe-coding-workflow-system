schema_version: 1
kind: vnext-protocol

# vNext Workflow Protocol

This protocol describes the vNext governed project surface. The project-local
Runtime is the only writer of authoritative task state. Bootstrap is an
administrative transaction that establishes governed assets and never creates
an active task or feature implementation.

The Vibe Governance Distribution is installed separately from governance
bootstrap. `Install != Bootstrap`: a fresh Node Distribution install provides
software and the canonical `.agents/skills/<skill-name>/SKILL.md` surface, but does not create
`PROJECT_PROFILE.yaml`, Contracts, Decisions, STATUS, or `CURRENT_TASK.md`.
The next required project transition is to invoke the `bootstrap-project` Agent
Skill.

## Authoritative boundaries

- `PROJECT_PROFILE.yaml` identifies the project and workflow home.
- `docs/workflow/CURRENT_TASK.md` is the sole task and advancement state source.
- Contracts, Decisions, Status, and host guidance are written only through
  their typed Runtime operation boundaries.
- vNext Skills are installed canonically under `.agents/skills/<skill-name>/SKILL.md`; old
  host-specific Skill directories are compatibility inputs only.
- Bootstrap-owned governance assets are staged, validated, promoted atomically,
  and read back; Distribution software is validated separately as a read-only
  prerequisite.
- An interruption marker is fail-closed evidence, not permission to guess a
  recovery action.

## P-13 Mutation Scope and Command Side Effects

P-13 also covers repo-local command side effects: tracked, untracked, ignored,
generated, build, cache, temporary, and helper writes are all mutations, and
`.gitignore` is not an exemption. A known write-capable command requires a
bounded `expected_write_footprint` admitted through the canonical scope
evaluator before execution; an unbounded footprint blocks the command. After
execution, available `observed_write_paths` are evaluated by the same guard,
and cleanup cannot turn a recorded unauthorized mutation into a pass. A final
Git diff is evidence only. Without OS-level monitoring, transient create/delete
history cannot be claimed complete.

## Mutation Authority v2

Mutation Authority v2 is an explicit task-versioned boundary. A v2 task must
declare `mutation_authority_version: 2` together with:

```yaml
mutation_authority:
  domains: [node-rollout]
  exact_exceptions: []
  forbidden: []
```

The project profile may define the stable ownership map:

```yaml
mutation_authority:
  domains:
    - id: node-rollout
      roots: [packages/node-rollout/**]
    - id: rust-rollout
      roots: [native/codex-rollout-collector/**]
```

Domain roots are bounded repository-relative exact paths or literal `/**`
prefixes. IDs are unique, roots owned by different domains may not overlap,
and path resolution fails closed when it is ambiguous. A path with no domain
is `unclassified` and cannot be admitted by ordinary same-envelope expansion.
The map is a mutation ownership boundary, not a dependency graph.

Authority domains are established through a project lifecycle. The `inventory`
mode proposes `authority_domain_candidates` from observed project structure;
those candidates carry evidence but grant no write permission. In `greenfield`,
`adopt`, or `realign`, the project owner may confirm the selected candidate
IDs/roots with a decision source and verbatim decision text. Only that explicit
confirmation is promoted into the canonical `PROJECT_PROFILE.yaml` map.
`prepare-task` selects the existing map and never guesses ownership or rebuilds
it for an individual task. A simple project may confirm one broad application
domain, but it still follows the same admission route.

Every confirmed v2 task records the stable revision/digest of the canonical
domain map in Runtime state. If the profile map changes, the active task fails
closed before execution admission and requires explicit authority
task authority-domain revalidation; ordinary correction-replan, P-12
admission, and exact-path amendment do not rebind it. It never inherits a
newly widened project grant.

Read/discovery is intentionally wider: the Agent may read, grep, trace callers,
inspect consumers, and establish root cause in another domain. None of that
creates write authority. Runtime allows writes only when the candidate path is
in the task's positive domain envelope or an explicitly authorized exact
exception, after applying task `forbidden` and fixed governance boundaries.
An out-of-envelope write is a hard
`MUTATION_AUTHORITY_EXPANSION_REQUIRED` blocker; it is not reported as a
generic v1 `PREFLIGHT_SCOPE_BLOCKED` result.

Before `prepare-task` confirms a v2 definition, Runtime proves every planned
target, exact command write, bounded command footprint, and persistent-test path
against the selected project authority. Planned targets need no blast-radius
assessment, but they must be inside an authorized domain or exact exception and
outside Forbidden/governance boundaries. Command writes use only an exact path
or literal `/**` directory-prefix grammar, and a command glob is admitted only
when its pattern is a deterministic subset of one granted domain root. An exact
exception never proves a directory glob; synthetic probe paths are not proof.

`implementation_steps[].planned_mutation_targets` is guidance, not an
independent v2 ACL. A target outside that planned footprint but inside the
envelope requires a Skill/model blast-radius assessment before it is admitted.
The assessment records the target/relevant symbol, reason, locality,
visibility, cross-component consumers, contract impact, evidence references,
and `self-admit` or `escalate` disposition. Runtime validates structure,
target binding, first-touch before-state, domain/forbidden/governance
boundaries and audit state; the Agent owns the semantic judgment. Caller-count
thresholds are not policy. Prefer the smallest correct local change; broader
shared changes need evidence that the local alternative would be incorrect,
duplicative, or contract-breaking. An elevated/high target may still be
self-admitted when its root-cause and regression/consumer evidence is strong;
uncertainty or multiple plausible directions escalates to the user.

Every self-admitted planned-footprint expansion is retained in audit, but
`dynamic_review_required` is selected from the assessment rather than from the
fact that the target was unplanned. A local/private/no-consumer/no-contract-impact
self-admission adds no checkpoint by itself; elevated, shared/public,
cross-component, contract-impact or uncertain expansion retains cumulative
review. If discovery happens after another path has already been modified, the
Agent calls the internal `execute-step:extend-preflight` action with the current
receipt, additional targets, assessments and evidence references regardless of
review depth. Runtime captures the new paths' before-state before first touch,
returns a replacement receipt, keeps the same attempt and plan revision, does
not consume retry budget, and does not create a continuation. Results must use
the newest receipt. A clean cumulative `review-change` is mandatory only when
the retained assessment or ordinary checkpoint requires it.

An existing test file inside the envelope follows ordinary expansion, while
the assessment and review must cover oracle/reuse/boundary changes. A new
persistent test whose first-touch state is absent still requires the full P-12
admission record. This preserves `new persistent test != ordinary file`.

Only a real authority change—such as Node to Rust/shared-protocol or a new
cross-domain exact exception—uses `prepare-task:amend-scope` with explicit
user authorization. An absent new persistent test inside an already
authorized domain uses the same infrastructure with a complete typed P-12
record and `authority_diff: none`; it is a real admission, not a no-op.
Same-envelope implementation discovery still uses `extend-preflight`. The
authority amendment settlement gate blocks only a preflighted attempt without
its matching recorded result; ready retries, settled blocked/repair results,
and pending review/findings may be preserved. The route keeps the old
immutable candidate, history/findings/review/budget lineage and continuation
semantics, and a committed candidate cannot be discarded. Tasks without the
v2 marker, or with version 1, retain legacy exact step-scope semantics and are
not silently reinterpreted.

## Public entry invocation terminal boundary

`public-entry-terminal/v1` is the canonical invocation boundary for every
public daily, administrative, and expert entry in the vNext surface. One
explicit public Skill invocation may complete only that entry's intent, its
declared internal capabilities, and its bound Runtime operations.

When the entry reaches its result—success, blocked, no-op, report, or another
declared terminal result—it must return to the caller and stop. A result may
contain at most one `next_route` recommendation for a later public entry or
mode, but that recommendation is informational only: the current invocation
must not invoke the next public Skill.

Internal capabilities and the Runtime operations declared by the current entry
are not public Skill chaining. Bootstrap's explicitly permitted `design` →
`greenfield` and `inventory` → `adopt` transitions remain internal mode
transitions of the same `bootstrap-project` invocation; they do not authorize
invoking another public Skill.

This is an instruction-level and host-guidance boundary. The current Runtime
cannot observe conversation-level public Skill invocations, so it must not be
described as machine-enforced by Runtime. Runtime continues to enforce only
the typed operations and write boundaries it can observe.

## Bootstrap modes

`design`, `greenfield`, `inventory`, `adopt`, and `realign` have distinct
preconditions. Confirmed facts retain provenance; inferred and unknown facts
remain visible and cannot silently become authority.

## Ordinary task lifecycle

`docs/workflow/CURRENT_TASK.md` is the only current-task owner. An independent
request may be prepared only after the prior task is `closed + archived` (the
bootstrap `TASK-000` baseline may be the first closed source without an
archive). The Runtime allocates the next unused identity and applies this
closed transition:

```text
closed + archived -> create-draft -> draft + active
draft + active -> update-draft -> draft + active
draft + active -> confirm-draft -> active + active
```

`draft + active` is durable but never executable. Repeated preparation must
preserve `TASK_ID`, `TASK_SLUG`, and `document_id`, replace only the typed task
definition, and must not auto-confirm or patch arbitrary Markdown. The only
draft-to-active route is explicit `prepare-task:confirm`, bound to the exact
current draft revision and explicit user or authorized-caller authority.
Execution and finding admission reject drafts until that Runtime transition
succeeds; the prior archive remains immutable.

New semantic and raw drafts use Runtime-owned `business_evidence_version: 1`.
The frozen Test Strategy retains mode/source/source_ref/task_classification/rationale.
Modes are `flexible`, `test-first`, `implementation-first`, `not-applicable`.
Authority precedence remains `explicit-user` > `project-policy` > `inferred-default`;
source_ref binds an exact Task Basis coordinate, existing policy file, or
`prepare-task-default`, respectively. Executable inferred defaults use `flexible`.
Explicit ordering retains its reason and relevant target through approved before-step
slots; absent prerequisite definitions remain TEST_STRATEGY_PREREQUISITE_UNSUPPORTED.
It must never be silently downgraded. No first-step Red, global tests-only split,
new-test obligation, or failed-first-run obligation is inferred from step
position alone. In an explicitly authorized `test-first` flow, Runtime may
represent the per-execution admission phase `red` only when the current step
has a frozen, unconsumed before-step expected-failure obligation. Candidate
filenames and candidate composition cannot select the phase. Red admits only
exact paths in frozen Persistent Tests, including non-typical test paths; its
`required_outcome` remains `implemented`, because expected-failure evidence is
the reproduction proof. Replacement preflight preserves that phase and
rejects any discovered product target before Runtime state changes.
`not-applicable` still requires non-executable-change, Persistent Tests=none,
and exact/subset admission under the project-owned
`PROJECT_PROFILE.yaml#boundaries.non_executable_change_paths` policy. Missing,
ambiguous or executable paths cannot prove this classification; Markdown alone
is not non-executable evidence. Persistent-test admission and review remain required.
Confirmation freezes the strategy; changes require authorized replan.
When an active or `blocked_by_replan` task has existing work, admitted findings,
or pending review and the user has already explicitly authorized an exact
additional path set, the caller may use the independent versioned
`scope-amendment-candidate/v1` route. In v2 this route is reserved for a path
outside the task authority envelope; an omitted same-domain helper or an
existing same-domain test uses `execute-step:extend-preflight` instead. Runtime
creates the candidate digest and receipt only after checking that the
caller-reported authorization covers every exact authority expansion path; the
source text is retained and the digest is never a second user authorization
object. Runtime commits a continuation step while preserving the old
definition, failures, obligations, findings, review baseline, review cycle,
pending review, and budget. It does not change the legacy
`correction-replan/v2` `permission_change: none` route. Preparation/amendment,
fresh preflight, real execution, revalidation, review, and closure remain
separate caller invocations; a successful amendment alone is not completion.
Implemented results require passed companions; an expected-failure result must
bind the exact admitted before-step reproduction check and successful report. Expected-failure/test-red remain historical data types, never positive
acceptance. New reproduction results must bind the admitted before-step check; they never satisfy positive acceptance.
Unversioned tasks remain readable, including archives, but execution/closure
returns `TASK_SEMANTICS_UPGRADE_REQUIRED`. Unknown versions fail closed. New
Runtime never silently upgrades an active task: use its previous installation
or an explicitly authorized replan. S1–S4 are local-only and not independently distributable.


For tasks with `claim_evidence_required: true`, prepare-task must persist a
non-empty frozen per-claim/per-slot evidence plan in the same canonical
`CURRENT_TASK.runtime_state`, including at least one `acceptance` claim.
Execution can update only planned slot disposition, `evidence_refs` and bound report; it
cannot create or redefine the plan at completion time. Every planned slot must
be `existing`, `reused`, or `newly-executed` and carry `evidence_refs`;
`missing`, `deferred`, or `blocked` evidence cannot become `task-complete`.
`close-task` consumes this durable state to derive `acceptance_satisfied` and
`validation_complete`; an aggregate command result or free-text note is not
sufficient. Legacy CURRENT_TASK documents remain readable, but require
prepare-task refinement/migration before terminal completion. For an active +
active legacy task, the canonical migration is the typed
`prepare-task:default:migrate-claim-evidence` task-state transaction: it
installs only a non-empty acceptance-bearing plan and preserves the existing
task identity, definition, scope, implementation state, execution history,
findings, review state, and lifecycle tuple. It is schema migration, not
business replan or lifecycle supersede. It does not add business_evidence_version
or remove the execution/closure version and evidence-plan gates.

## Durable Lesson marker boundary

The installed vNext Runtime accepts only the current
`vnext-lesson-marker/canonical-v1` marker shape under `schema_version: 1`.
Persisted markers omit `disposition`; reused markers use
`disposition: reused` and an exact `reused_candidate` target containing
`task_id`, `document_id`, `archive_revision`, and `candidate_ref`. The
Candidate Identity fields use the same strict validators for the persisted
identity and reuse target, while `task_slug` uses the canonical task-slug
validator. Unknown or missing fields and invalid disposition values fail as
`LESSON_INVALID`; a digest or visible provenance mismatch fails as
`LESSON_PROVENANCE_MISMATCH`. The Runtime applies this canonical closed-schema
validation without guessing or silently reinterpreting non-canonical durable
state. If a future released supported durable schema changes incompatibly, an
explicit schema-evolution / offline-migration boundary must be defined before
ordinary readers accept the new shape.

## Record-only inbox binding

`capture-work-item` may submit one `capture-work-item:record` typed proposal to
the bound `inbox-record-transaction`. Runtime admits only a complete
`relation_to_current_task: unrelated` proof with resolved duplicate and owner
fields, derives the canonical `TASKS/inbox/INBOX-<YYYYMMDD>-<short-id>-<slug>.md`
target, and commits at most that one file. Stale source tuples, unsafe or
non-canonical targets, identity/provenance collisions, and failed read-back
are fail-closed; the active task and every other governance/product file stay
byte-identical.

## Expert validation boundary

`validate-change` is an expert/automation entry for one explicit validation
target. It applies evidence admission to select the minimum-sufficient
claim-appropriate evidence and returns an ephemeral `validation_result`.
Evidence kinds may include static proof, an existing regression, a focused
test, integration smoke, browser/session, visual, real-device, external
documentation, or release-health evidence; these are policy choices, not
public modes. The entry has no Runtime operation and must not mutate product,
governance, task, finding, host, or persistent-test state. A failed result is
not a finding admission, and a missing persistent regression is an evidence gap
that must return a terminal result with an optional `recommended_route` for a
later caller invocation of an entry with explicit P-12 write authority; the
current invocation must not invoke or hand off to that entry.

## Durable Contract / Decision promotion

`close-task` evaluates Contract, Decision, and Lesson candidates before archive
with the existing knowledge-admission policy. `admit`, `merge`, and `supersede`
Contract/Decision results become typed `contract-candidate-commit` or
`decision-record-transaction` proposals only after the archive is committed;
`defer`, `reject`, and `no-op` do not write. Runtime, not a Skill, owns the
canonical `CONTRACTS.md` / `DECISIONS.md` format, deduplication, provenance,
conflict, atomicity, and read-back.

The canonical task archive stores the complete knowledge admission bundle.
On closed-task re-entry, close-task reconstructs candidates from that durable
bundle and writes only missing records; existing exact records are no-ops,
provenance/identity conflicts fail closed, and archive/current terminal state
is never repeated or rewritten. No separate pending registry is introduced.

Contract and Decision records may include optional `implementation_anchors`
(zero to five `observed` or `verified-scope` path/symbol/role/evidence hints).
Anchors are navigation seeds, not completeness or mutation authority. Consumers
validate them against current code and expand live impact analysis according to
risk; stale anchors trigger broader search rather than trusted historical
locations.

### Business evidence completion (S2)

Prepare accepts stable claim/slot/check definitions, with acceptance rendered from
claims. Record-step-result merges exact slot reports; command success never fills
unreported flow slots. Step completion checks due obligations and close checks all
obligations using one Runtime evaluator, including current subject hashes and
retained artifacts. Caller-reported is the only supported assurance. No string
label supplies a trusted Provider or authenticated human signature.

The internal record-step-preflight transaction consumes approved prerequisites
and records first-touch review preimages before editing. It preserves pending review and budgets; findings route to
begin-repair, clean to complete-reviewed-step, blocked to its recorded route.
Consumed reproduction snapshots remain historical while current repair evidence
must match the repaired subjects. New definitions never import prior receipts.

P-12 admission binds persistent test paths to stable claims, source/owner,
necessity, existing evidence insufficiency and assertion boundary. Review checks
oracle independence and whether mocks actually cross the claimed boundaries.
Each step declares required/not-required and a reason; omitted semantic input
retains conservative required review for compatibility, never an implicit waiver.
A required checkpoint reviews the cumulative task delta from first-touch content,
including earlier exempt steps. The final checkpoint is required unless its
confirmed reason explicitly starts with `final-exemption:` and explains why the
entire cumulative task may be exempt. Project-required reviews cannot be waived.
Clean completion consumes pending coverage; findings, blocked and stale results
preserve it. Repair still requires verification. The internal retry-step action
can restore a recorded environment blocker or a confirmed same-plan current-step
failed check to ready only when its distinct evidence and scope gates pass. It
retains failure evidence and permits at most three attempts in canonical
step_attempts. Retry never completes the step: a fresh preflight and execution
are required. Unknown causes, changed plans, and open findings do not use this
retry; no server restart or database reset is an implicit recovery action.

## Current view, state, and complete history (0.20.7)

This additive storage contract preserves task identity, goal, acceptance,
authority, scope, test admission, review / repair budgets, and lifecycle
semantics. CURRENT_TASK.md remains the fixed human and Agent entrypoint. Its
single submission head selects the current source, definition, state, and
committed event range. Inline and compact-v2 tasks retain their original
complete definition presentation; execution and idempotency arrays are only a
compatibility hot-cache. New compact-v3 tasks keep exact immutable definition
and state references with current-step navigation in CURRENT_TASK, rather than
repeating the complete plan, claims and reports inline. The referenced material
belongs to the same canonical aggregate and is resolved through task-context /
task-read before execution. Summary text never grants authority. Existing tasks
remain readable; explicit representation-only task-storage-migration preserves
the old raw source and complete logical semantics without replan or a size gate.
Already-issued business receipts survive only a Runtime-proven storage-only
lineage with unchanged logical semantics; no business transaction is treated as
an equivalent source. Keep original receipts rather than repeating approval or
preflight after admitted edits. The v3 presentation model is versioned; YAML
emission changes alone do not invalidate intact historical material.
Complete history remains in the bound task-data aggregate and is never treated
as empty when the active preview is short.

The aggregate is stored under
<workflow_home>/task-data/<document_id>/ with a manifest, immutable
content-addressed objects/<sha256>.json, immutable
events/<sequence>-<sha256>.json, and rebuildable non-authoritative indexes.
Only objects and events acknowledged by the manifest head are committed facts.
Deduplication never merges independent execution, review, authorization,
result, or idempotency events. v1 has no automatic garbage collection, and
distribution upgrade / uninstall must not remove target-owned task-data.

Daily callers use the read-only task-context projection and exact task-read
references. Required projection content includes the current definition (or an
exact same-visible-session revision), current-step requirements, unfinished
obligations, recorded and unknown dependencies, global gates, latest execution,
and cumulative review target. It must not expand raw runtime state or
unbounded history by a recent-N heuristic. All metadata, lists, JSON, and text
use the UTF-8 byte budget and continuation fields; incomplete required content
is not complete. Receipts prove only version and returned range, never write
authority or execution qualification.

The normal sequence is `validate --summary` -> `task-context(entry, mode)` ->
all required continuation pages -> exact `task-read`/`file-context`/
`review-read` -> the existing preflight, execute, review, recovery, or lifecycle
operation. A pending journal, missing object, or revision conflict is a
recovery/error state and cannot be bypassed by reading the old full Markdown
history.

validate --summary checks the current aggregate and direct references;
validate --deep is the explicit full-history diagnostic. Storage migration is
a separate preview -> exact source_revision confirmation -> commit action. It
preserves exact legacy bytes, known history, and old locator aliases; a missing
preimage remains explicitly missing.

### Task-level user decisions and engineering adjustments

Explicit human observations and risk waivers use the source-bound internal
prepare-task commands defined in FILE_SCHEMAS.md. They are caller-reported:
manual acceptance is not automated PASS, and waiver is not evidence. Critical
invariants, prerequisites, policy, required review and findings are not bypassed.
An exact pending `REPAIR_BUDGET_EXHAUSTED` review remains owned by its findings,
not correction replan. With an explicit caller-reported user decision,
`prepare-task:extend-repair-budget` adds exactly one attempt to every and only
currently exhausted finding, records the decision/audit, and preserves the task,
pending review, attempts, baseline, and evidence obligations. The retained review
then routes directly to `execute-step:repair`; without that decision it remains a
user-owned blocker. Default limits do not change, and explicit extensions are
bounded by the Runtime absolute limits. If only the repair-wave quota is
exhausted, the same decision may use `extension_scope: repair-round` with an
empty fingerprint set; this extends only the cycle quota and preserves every
finding attempt count. A blocked review keeps its structured findings,
unresolved fingerprints, and resolved fingerprints; verified resolutions update
the finding queue in the same Runtime transaction, and the extra-budget
authorization is not a replacement for the full repair target set.
Local equivalent read-only validation adjustments use execute-step's internal
replace-validation, preserving the task and its obligations. Low-risk private
same-domain discoveries do not add a review beyond the confirmed checkpoint;
elevated expansions retain cumulative review.

Only a genuine task invalidation permits supersede. A later explicit replacement
request may prepare a fresh successor with complete old-obligation disposition;
it cannot erase unfinished facts or execute before ordinary draft confirmation.
Supersede never automatically creates or approves a replacement.


### Same-task evidence-selection amendment

An explicit user decision may revise verification selection without replacing the
task's goal, acceptance, authority or business boundary. The internal
prepare/confirm/discard-evidence-plan-amendment commands are owned by prepare-task.
Preparation preserves the live task; confirmation versions only admitted check
selection and bound read-only current/future commands. It requires no challenge
when no report exists. Findings, failures and budgets persist. Affected reports
are historical, not new-plan evidence; a pending findings review remains active,
while an affected clean review is retained explicitly as historical and requires
fresh validation/review. Neither test deletion nor supersede follows from this
operation. The existing equivalent-invocation and genuine counterevidence routes
keep their original, narrower contracts.

import { runCli } from './kernel';
import { runBootstrapCli } from './bootstrap';
import { runBootstrapSupportCli } from './bootstrap-support';
import { PREPARE_TASK_ADAPTER_COMMANDS, runPrepareTaskAdapterCli } from './prepare-task-adapter';
import { EXECUTE_STEP_ADAPTER_COMMANDS, runExecuteStepAdapterCli } from './execute-step-adapter';
import { REVIEW_CHANGE_ADAPTER_COMMANDS, runReviewChangeAdapterCli } from './review-change-adapter';
import { runFileContextCli } from './file-context-cli';
import { runTaskContextCli } from './task-context';

export { runCli, runBootstrapCli, runBootstrapSupportCli, runPrepareTaskAdapterCli, runExecuteStepAdapterCli, runReviewChangeAdapterCli, runTaskContextCli };

const args = process.argv.slice(2);
let runner: Promise<number>;
if (args[0] === 'file-context') runner = runFileContextCli(args.slice(1));
else if (args[0] === 'task-context' || args[0] === 'task-read' || args[0] === 'task-storage-migration' || args[0] === 'task-migrate' || args[0] === 'task-export') {
  runner = runTaskContextCli(args[0] === 'task-migrate' ? 'task-storage-migration' : args[0], args.slice(1));
}
else if (args[0] === 'bootstrap-project') runner = runBootstrapCli(args.slice(1));
else if (args[0] === 'bootstrap-support') runner = runBootstrapSupportCli(args.slice(1));
else if (PREPARE_TASK_ADAPTER_COMMANDS.includes(args[0] as (typeof PREPARE_TASK_ADAPTER_COMMANDS)[number])) {
  runner = runPrepareTaskAdapterCli(args);
} else if (EXECUTE_STEP_ADAPTER_COMMANDS.includes(args[0] as (typeof EXECUTE_STEP_ADAPTER_COMMANDS)[number])) {
  runner = runExecuteStepAdapterCli(args);
} else if (REVIEW_CHANGE_ADAPTER_COMMANDS.includes(args[0] as (typeof REVIEW_CHANGE_ADAPTER_COMMANDS)[number])) {
  runner = runReviewChangeAdapterCli(args);
} else runner = runCli(args);

runner.then((exitCode) => {
  process.exitCode = exitCode;
});
